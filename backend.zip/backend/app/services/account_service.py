class AccountService:
    def __init__(self, db):
        self.db = db

    def create_account(self, account_data):
        # logic here
        pass