backend/CHANGELOG.md
[Unreleased]
(Add next backend features, migrations, or bugfixes here.)

[v0.1.0] — 2025-07-21
Added
Initial project scaffolding using FastAPI for REST API.

Set up and configured PostgreSQL as the main database.

Integrated SQLAlchemy as ORM for data models.

Added database connection utility (db.py or similar).

Created essential API entities and models:

User (registration, authentication, JWT/session, password hashing)

Transaction (CRUD: create, read, update, delete)

Account (list, create, link to users/transactions)

Budget (track by category, time period)

Category (expense/income types)

Implemented basic API endpoints:

POST /register, POST /login (with JWT or session cookies)

GET /transactions, POST /transactions, DELETE /transactions/{id}

GET /budgets, POST /budgets

GET /accounts, POST /accounts

API response validation with Pydantic schemas.

Initial unit tests for registration and transaction creation.

Simple API documentation via FastAPI’s automatic Swagger UI.

Changed
Improved security with password hashing (bcrypt or argon2).

Added CORS middleware for frontend integration.

Updated models to support user-level scoping (multi-user, isolated data).

Refined error handling (404, 401, 500).

Fixed
Fixed DB migration script errors for first-time setup.

Fixed authentication bugs with login/refresh tokens.

Fixed bug where new transactions were not saving associated user ID.

Fixed category mapping bug (ensured only valid categories used).

Improved
Added sample data population script for local development.

Improved API response messages (success, errors).

Enabled cross-origin requests for frontend-localhost use.

Discussed
How to structure RESTful endpoints for flexibility and security.

Best practice for API key/token authentication.

Handling user registration edge cases.

Database schema relationships for accounts, budgets, and transactions.

API error message format for frontend compatibility.

[To Do / Next Up]
Add password reset and email verification endpoints.

Support recurring transactions and notifications.

Add reporting endpoints (charts, summaries, analytics).

Rate-limit and throttle endpoints for security.

Improve test coverage.

Set up deployment-ready Dockerfile and environment.

Backend Lead: Bill Etornam Kwame Gbadago
Backend Team: Bill, Enoch
Last updated: 2025-07-25