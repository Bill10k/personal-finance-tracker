// src/data/budgetData.js
export const budgetData = [
    { category: "Food", spent: 245, limit: 500 },
    { category: "Transportation", spent: 120, limit: 200 },
    { category: "Entertainment", spent: 75, limit: 300 },
    { category: "Rent", spent: 500, limit: 500 },
  ]
  