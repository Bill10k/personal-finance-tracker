import {
  require_react
} from "./chunk-3ARHY7UZ.js";
export default require_react();
