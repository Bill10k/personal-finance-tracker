// App.jsx
import React, { useState } from 'react'
import LoginForm from './Components/Login'
import ForgotPassword from './Components/ForgotPassword'
import Dashboard from './Components/Dashboard'
import AddTransaction from './Components/AddTransaction'
import History from './Components/History'
import Budget from './Components/Budget'

const App = () => {
  const [screen, setScreen] = useState('login')

  return (
    <>
      {screen === 'login' && (
        <div
          className="grid w-full h-screen place-items-center bg-cover bg-center"
          style={{
            backgroundImage: `url('/src/assets/background.png')`,
            backgroundRepeat: 'no-repeat',
            backgroundSize: 'cover',
          }}
        >
          <LoginForm
            onForgot={() => setScreen('forgot')}
            onLoginSuccess={() => setScreen('dashboard')}
          />
        </div>
      )}

      {screen === 'forgot' && (
        <div
          className="grid w-full h-screen place-items-center bg-cover bg-center"
          style={{
            backgroundImage: `url('/src/assets/background.png')`,
            backgroundRepeat: 'no-repeat',
            backgroundSize: 'cover',
          }}
        >
          <ForgotPassword onBack={() => setScreen('login')} />
        </div>
      )}

      {screen === 'dashboard' && <Dashboard currentScreen="dashboard" setScreen={setScreen} />}
      {screen === 'addTransaction' && <AddTransaction currentScreen="addTransaction" setScreen={setScreen} />}
      {screen === 'history' && <History currentScreen="history" setScreen={setScreen} />}
      {screen === 'budget' && <Budget currentScreen="budget" setScreen={setScreen} />}
    </>
  )
}

export default App
