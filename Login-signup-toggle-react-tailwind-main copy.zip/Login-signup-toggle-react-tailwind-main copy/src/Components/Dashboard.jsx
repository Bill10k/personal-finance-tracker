import Navbar from './Navbar'
import OverviewCard from './OverviewCard'
import Chart from './Chart'
import BudgetItem from './BudgetItem'
import TransactionItem from './TransactionItem'

import { overviewData } from '../data/overviewData'
import { expensesData } from '../data/expensesData'
import { budgetData } from '../data/budgetData'
import { transactions } from '../data/transactions'

const Dashboard = ({ currentScreen, setScreen }) => {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Navbar currentScreen={currentScreen} setScreen={setScreen} />

      {/* Dashboard content */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        {overviewData.map((card, index) => (
          <OverviewCard key={index} {...card} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-6">
        <Chart data={expensesData} />
        <div className="space-y-4">
          {budgetData.map((item, index) => (
            <BudgetItem key={index} {...item} />
          ))}
        </div>
      </div>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Recent Transactions</h2>
        <div className="space-y-2">
          {transactions.map((txn, index) => (
            <TransactionItem key={index} {...txn} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default Dashboard
