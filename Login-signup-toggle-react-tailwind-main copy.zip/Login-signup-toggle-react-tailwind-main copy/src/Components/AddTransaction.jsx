import Navbar from './Navbar'

const AddTransaction = ({ currentScreen, setScreen }) => {
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <Navbar currentScreen={currentScreen} setScreen={setScreen} />
      <div className="mt-10 text-center text-gray-500">
        Add Transaction Page Coming Soon...
      </div>
    </div>
  )
}

export default AddTransaction
