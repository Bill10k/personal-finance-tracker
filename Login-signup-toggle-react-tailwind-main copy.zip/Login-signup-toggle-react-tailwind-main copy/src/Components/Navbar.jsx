import logo from '../assets/logo.svg'

const Navbar = ({ currentScreen, setScreen }) => {
  const links = [
    { label: 'Dashboard', key: 'dashboard' },
    { label: 'Add Transaction', key: 'addTransaction' },
    { label: 'History', key: 'history' },
    { label: 'Budget', key: 'budget' },
  ]

  return (
    <nav className="bg-white shadow p-4 flex justify-between items-center">
      <div className="flex items-center gap-2">
        <img src={logo} alt="Susu App Logo" className="w-8 h-8" />
        <h1 className="text-xl font-bold text-[#6FE0A9]">Susu App</h1>
      </div>

      <ul className="flex gap-6 text-gray-700">
        {links.map((link) => (
          <li
            key={link.key}
            onClick={() => setScreen(link.key)}
            className={`cursor-pointer ${
              currentScreen === link.key
                ? 'text-[#6FE0A9] underline underline-offset-4 font-semibold'
                : 'hover:text-[#6FE0A9]'
            }`}
          >
            {link.label}
          </li>
        ))}
      </ul>

      <span className="text-sm text-gray-500">Welcome back, Kobby</span>
    </nav>
  )
}

export default Navbar
