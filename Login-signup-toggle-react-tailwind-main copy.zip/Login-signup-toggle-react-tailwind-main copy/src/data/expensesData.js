// src/data/expensesData.js
export const expensesData = [
    { name: "Rent", value: 500, color: "#F87171" },
    { name: "Food", value: 300, color: "#60A5FA" },
    { name: "Transport", value: 150, color: "#34D399" },
  ]
  